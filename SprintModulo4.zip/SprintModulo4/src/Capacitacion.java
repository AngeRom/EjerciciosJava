public class Capacitacion {
    private Integer id_capacitacion;
    private Integer rut_cliente;
    private String dia_capacitacion;
    private String hora_capacitacion;
    private String lugar_capacitacion;
    private String duracion_capacitacion;
    private Integer cant_asistentes_capacitacion;

    @Override
    public String toString() {
        return "Capacitacion{" +
                "id_capacitacion=" + id_capacitacion +
                ", rut_cliente='" + rut_cliente + '\'' +
                ", dia_capacitacion='" + dia_capacitacion + '\'' +
                ", hora_capacitacion='" + hora_capacitacion + '\'' +
                ", lugar_capacitacion='" + lugar_capacitacion + '\'' +
                ", duracion_capacitacion='" + duracion_capacitacion + '\'' +
                ", cant_asistentes_capacitacion=" + cant_asistentes_capacitacion +
                '}';
    }

    public Capacitacion() {
    }

    public Capacitacion(Integer id_capacitacion, Integer rut_cliente, String dia_capacitacion, String hora_capacitacion, String lugar_capacitacion, String duracion_capacitacion, Integer cant_asistentes_capacitacion) {
        this.id_capacitacion = id_capacitacion;
        this.rut_cliente = rut_cliente;
        this.dia_capacitacion = dia_capacitacion;
        this.hora_capacitacion = hora_capacitacion;
        this.lugar_capacitacion = lugar_capacitacion;
        this.duracion_capacitacion = duracion_capacitacion;
        this.cant_asistentes_capacitacion = cant_asistentes_capacitacion;
    }

    public Integer getId_capacitacion() {
        return id_capacitacion;
    }

    public void setId_capacitacion(Integer id_capacitacion) {
        this.id_capacitacion = id_capacitacion;
    }

    public Integer getRut_cliente() {
        return rut_cliente;
    }

    public void setRut_cliente(Integer rut_cliente) {
        this.rut_cliente = rut_cliente;
    }

    public String getDia_capacitacion() {
        return dia_capacitacion;
    }

    public void setDia_capacitacion(String dia_capacitacion) {
        this.dia_capacitacion = dia_capacitacion;
    }

    public String getHora_capacitacion() {
        return hora_capacitacion;
    }

    public void setHora_capacitacion(String hora_capacitacion) {
        this.hora_capacitacion = hora_capacitacion;
    }

    public String getLugar_capacitacion() {
        return lugar_capacitacion;
    }

    public void setLugar_capacitacion(String lugar_capacitacion) {
        this.lugar_capacitacion = lugar_capacitacion;
    }

    public String getDuracion_capacitacion() {
        return duracion_capacitacion;
    }

    public void setDuracion_capacitacion(String duracion_capacitacion) {
        this.duracion_capacitacion = duracion_capacitacion;
    }

    public Integer getCant_asistentes_capacitacion() {
        return cant_asistentes_capacitacion;
    }

    public void setCant_asistentes_capacitacion(Integer cant_asistentes_capacitacion) {
        this.cant_asistentes_capacitacion = cant_asistentes_capacitacion;
    }

    public void mostrarDetalles(){
        System.out.println("La capacitación será en " + lugar_capacitacion + " a las " + hora_capacitacion + " el día " + dia_capacitacion + " y durará " + duracion_capacitacion +" minutos.");
    }
}
