import java.util.ArrayList;
import java.util.List;

public class Contenedor {
    List<Asesoria> lista_asesoria = new ArrayList<>();
    List<Capacitacion> lista_capacitacion = new ArrayList<>();

    public void almacenarCliente(Cliente cliente){
        this.lista_asesoria.add(cliente);
    }

    public void almacenarProfesional(Profesional profesional){
        this.lista_asesoria.add(profesional);
    }

    public void almacenarAdministrativo(Administrativo administrativo){
        this.lista_asesoria.add(administrativo);
    }

    public void almacenarCapacitacion(Capacitacion capacitacion){
        this.lista_capacitacion.add(capacitacion);
    }

    public void eliminarUsuario(){
        this.lista_asesoria.clear();
        System.out.println();
    }

    public void listarUsuarios(){
        System.out.println("Lista Usuarios: " + lista_asesoria);
    }

    public void listarUsuarioTipo(){

    }

    public void listarCapacitaciones(){
        System.out.println("Lista Capacitaciones: " + lista_capacitacion);
    }
}