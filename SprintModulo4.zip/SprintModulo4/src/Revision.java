public class Revision {
    private Integer id_revision;
    private Integer id_visita_terreno;
    private String nombre_revision;
    private String detalle_revision;
    private Integer revision_estado;

    @Override
    public String toString() {
        return "Revision{" +
                "id_revision=" + id_revision +
                ", id_visita_terreno=" + id_visita_terreno +
                ", nombre_revision='" + nombre_revision + '\'' +
                ", detalle_revision='" + detalle_revision + '\'' +
                ", revision_estado=" + revision_estado +
                '}';
    }

    public Revision() {
    }

    public Revision(Integer id_revision, Integer id_visita_terreno, String nombre_revision, String detalle_revision, Integer revision_estado) {
        this.id_revision = id_revision;
        this.id_visita_terreno = id_visita_terreno;
        this.nombre_revision = nombre_revision;
        this.detalle_revision = detalle_revision;
        this.revision_estado = revision_estado;
    }

    public Integer getId_revision() {
        return id_revision;
    }

    public void setId_revision(Integer id_revision) {
        this.id_revision = id_revision;
    }

    public Integer getId_visita_terreno() {
        return id_visita_terreno;
    }

    public void setId_visita_terreno(Integer id_visita_terreno) {
        this.id_visita_terreno = id_visita_terreno;
    }

    public String getNombre_revision() {
        return nombre_revision;
    }

    public void setNombre_revision(String nombre_revision) {
        this.nombre_revision = nombre_revision;
    }

    public String getDetalle_revision() {
        return detalle_revision;
    }

    public void setDetalle_revision(String detalle_revision) {
        this.detalle_revision = detalle_revision;
    }

    public Integer getRevision_estado() {
        return revision_estado;
    }

    public void setRevision_estado(Integer revision_estado) {
        this.revision_estado = revision_estado;
    }
}
