import java.util.Scanner;

public class CapacitacionOperaciones {
    public Capacitacion leerCapacitacion(){
        Capacitacion capacitacion = new Capacitacion();
        Scanner leer = new Scanner(System.in);

        Integer id_capacitacion;
        do{
            System.out.println("Ingrese ID de capacitación:");
            id_capacitacion = leer.nextInt();
        }while(capacitacion.getId_capacitacion() != null);

        Integer rut_cliente;
        do{
            System.out.println("Ingrese RUT del cliente:");
            rut_cliente = leer.nextInt();
        }while (rut_cliente > 99999999);

        String dia_capacitacion;
        do{
            System.out.println("Ingrese día de capacitación:");
            dia_capacitacion = leer.next();
        }while(capacitacion.getDia_capacitacion() != null);

        String hora_capacitacion;
        do{
            System.out.println("Ingrese hora de capacitación en formato HH:MM");
            hora_capacitacion = leer.next();
        }while(capacitacion.getHora_capacitacion() != null);

        String lugar_capacitacion;
        do{
            System.out.println("Ingrese lugar de capacitación:");
            lugar_capacitacion = leer.next();
        }while(capacitacion.getLugar_capacitacion() != null);

        String duracion_capacitacion;
        do{
            System.out.println("Ingrese duración de capacitación:");
            duracion_capacitacion = leer.next();
        }while(capacitacion.getDuracion_capacitacion() != null);

        Integer cantidad_asistentes_capacitacion;
        do{
            System.out.println("Ingrese cantidad de asistentes a la capacitación:");
            cantidad_asistentes_capacitacion = leer.nextInt();
        }while(capacitacion.getCant_asistentes_capacitacion() > 1000);

        return capacitacion;
    }
}
