public class Accidente {
    private Integer id_accidente;
    private Integer rut_cliente;
    private String fecha_accidente;
    private String hora_accidente;
    private String lugar_accidente;
    private String origen_accidente;
    private String consecuencias_accidente;

    @Override
    public String toString() {
        return "Accidente{" +
                "id_accidente=" + id_accidente +
                ", rut_cliente='" + rut_cliente + '\'' +
                ", fecha_accidente='" + fecha_accidente + '\'' +
                ", hora_accidente='" + hora_accidente + '\'' +
                ", lugar_accidente='" + lugar_accidente + '\'' +
                ", origen_accidente='" + origen_accidente + '\'' +
                ", consecuencias_accidente='" + consecuencias_accidente + '\'' +
                '}';
    }

    public Accidente() {
    }

    public Accidente(Integer id_accidente, Integer rut_cliente, String fecha_accidente, String hora_accidente, String lugar_accidente, String origen_accidente, String consecuencias_accidente) {
        this.id_accidente = id_accidente;
        this.rut_cliente = rut_cliente;
        this.fecha_accidente = fecha_accidente;
        this.hora_accidente = hora_accidente;
        this.lugar_accidente = lugar_accidente;
        this.origen_accidente = origen_accidente;
        this.consecuencias_accidente = consecuencias_accidente;
    }

    public Integer getId_accidente() {
        return id_accidente;
    }

    public void setId_accidente(Integer id_accidente) {
        this.id_accidente = id_accidente;
    }

    public Integer getRut_cliente() {
        return rut_cliente;
    }

    public void setRut_cliente(Integer rut_cliente) {
        this.rut_cliente = rut_cliente;
    }

    public String getFecha_accidente() {
        return fecha_accidente;
    }

    public void setFecha_accidente(String fecha_accidente) {
        this.fecha_accidente = fecha_accidente;
    }

    public String getHora_accidente() {
        return hora_accidente;
    }

    public void setHora_accidente(String hora_accidente) {
        this.hora_accidente = hora_accidente;
    }

    public String getLugar_accidente() {
        return lugar_accidente;
    }

    public void setLugar_accidente(String lugar_accidente) {
        this.lugar_accidente = lugar_accidente;
    }

    public String getOrigen_accidente() {
        return origen_accidente;
    }

    public void setOrigen_accidente(String origen_accidente) {
        this.origen_accidente = origen_accidente;
    }

    public String getConsecuencias_accidente() {
        return consecuencias_accidente;
    }

    public void setConsecuencias_accidente(String consecuencias_accidente) {
        this.consecuencias_accidente = consecuencias_accidente;
    }
}