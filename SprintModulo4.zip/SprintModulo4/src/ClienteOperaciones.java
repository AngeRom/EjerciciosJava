import java.util.Scanner;

public class ClienteOperaciones {

    public Cliente leerCliente() {
        Cliente cliente = new Cliente();
        Scanner leer = new Scanner(System.in);

        Integer rut_cliente;
        do {
            System.out.println("Ingrese RUT de cliente:");
            rut_cliente = leer.nextInt();
        } while (rut_cliente > 99999999);

        String nombres_cliente;
        do {
            System.out.println("Ingrese nombres de cliente:");
            nombres_cliente = leer.next();
        } while (cliente.getNombres_cliente() != null);

        String apellidos_cliente;
        do {
            System.out.println("Ingrese apellidos de cliente:");
            apellidos_cliente = leer.next();
        } while (cliente.getApellidos_cliente() != null);

        Integer telefono_cliente;
        do {
            System.out.println("Ingrese teléfono de cliente:");
            telefono_cliente = leer.nextInt();
        } while (cliente.getTelefono_cliente() != null);

        String afp_cliente;
        System.out.println("Ingrese AFP de cliente:");
        afp_cliente = leer.next();

        Integer sistema_salud_cliente;
        do{
            System.out.println("Ingrese sistema de salud de cliente: 1-Fonasa o 2-Isapre");
            sistema_salud_cliente = leer.nextInt();
        }while(sistema_salud_cliente == 1 && sistema_salud_cliente == 2);

        String direccion_cliente;
        System.out.println("Ingrese dirección del cliente:");
        direccion_cliente = leer.next();

        String comuna_cliente;
        System.out.println("Ingrese comuna del cliente:");
        comuna_cliente = leer.next();

        Integer edad_cliente;
        do {
            System.out.println("Ingrese edad del cliente");
            edad_cliente = leer.nextInt();
        } while (edad_cliente <= 0 && edad_cliente > 150);

        return cliente;
    }
}