public class Profesional extends Usuario{
    private String titulo_profesional;
    private String fecha_ingreso_profesional;

    @Override
    public String toString() {
        return "Profesional{" +
                "titulo_profesional='" + titulo_profesional + '\'' +
                ", fecha_ingreso_profesional='" + fecha_ingreso_profesional + '\'' +
                '}';
    }

    public Profesional() {
    }

    public Profesional(String titulo_profesional, String fecha_ingreso_profesional) {
        this.titulo_profesional = titulo_profesional;
        this.fecha_ingreso_profesional = fecha_ingreso_profesional;
    }

    public String getTitulo_profesional() {
        return titulo_profesional;
    }

    public void setTitulo_profesional(String titulo_profesional) {
        this.titulo_profesional = titulo_profesional;
    }

    public String getFecha_ingreso_profesional() {
        return fecha_ingreso_profesional;
    }

    public void setFecha_ingreso_profesional(String fecha_ingreso_profesional) {
        this.fecha_ingreso_profesional = fecha_ingreso_profesional;
    }

    @Override
    public void analizarUsuario() {
        //super.analizarUsuario();
        this.toString();
        System.out.println(this.toString());
        //System.out.println(titulo_profesional + " - " + fecha_ingreso_profesional);
    }
}
