import java.util.Scanner;

public class AdministrativoOperaciones {

    public Administrativo leerAdministrativo(){
        Administrativo administrativo = new Administrativo();
        Scanner leer = new Scanner(System.in);

        String area_administrativo;
        do{
            System.out.println("Ingrese área de Administrativo:");
            area_administrativo = leer.next();
        }while(area_administrativo != null);

        String experiencia_previa_administrativo;
        do{
            System.out.println("Ingrese experiencia previa:");
            experiencia_previa_administrativo = leer.next();
        }while(experiencia_previa_administrativo != null);

        return administrativo;
    }
}