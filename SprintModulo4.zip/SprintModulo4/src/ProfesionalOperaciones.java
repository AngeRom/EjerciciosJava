import java.util.Scanner;

public class ProfesionalOperaciones {

    public Profesional leerProfesional(){
        Profesional profesional = new Profesional();
        Scanner leer = new Scanner(System.in);

        String titulo_profesional;
        do{
            System.out.println("Ingrese Título del profesional:");
            titulo_profesional = leer.next();
        }while(profesional.getTitulo_profesional() != null);

        String fecha_ingreso_profesional;
        do{
            System.out.println("Ingrese fecha de ingreso en formato DD/MM/AAAA:");
            fecha_ingreso_profesional = leer.next();
        }while(profesional.getFecha_ingreso_profesional() != null);

        return profesional;
    }
}