public class Cliente extends Usuario{
    private Integer rut_cliente;
    private String nombres_cliente;
    private String apellidos_cliente;
    private Integer telefono_cliente;
    private String afp_cliente;
    private Integer sistema_salud_cliente;
    private String direccion_cliente;
    private String comuna_cliente;
    private Integer edad_cliente;

    @Override
    public String toString() {
        return "Cliente{" +
                "rut_cliente='" + rut_cliente + '\'' +
                ", nombres_cliente='" + nombres_cliente + '\'' +
                ", apellidos_cliente='" + apellidos_cliente + '\'' +
                ", telefono_cliente=" + telefono_cliente +
                ", afp_cliente='" + afp_cliente + '\'' +
                ", sistema_salud_cliente=" + sistema_salud_cliente +
                ", direccion_cliente='" + direccion_cliente + '\'' +
                ", comuna_cliente='" + comuna_cliente + '\'' +
                ", edad_cliente=" + edad_cliente +
                '}';
    }

    public Cliente() {
    }

    public Cliente(Integer rut_cliente, String nombres_cliente, String apellidos_cliente, Integer telefono_cliente, String afp_cliente, Integer sistema_salud_cliente, String direccion_cliente, String comuna_cliente, Integer edad_cliente) {
        this.rut_cliente = rut_cliente;
        this.nombres_cliente = nombres_cliente;
        this.apellidos_cliente = apellidos_cliente;
        this.telefono_cliente = telefono_cliente;
        this.afp_cliente = afp_cliente;
        this.sistema_salud_cliente = sistema_salud_cliente;
        this.direccion_cliente = direccion_cliente;
        this.comuna_cliente = comuna_cliente;
        this.edad_cliente = edad_cliente;
    }

    public Integer getRut_cliente() {
        return rut_cliente;
    }

    public void setRut_cliente(Integer rut_cliente) {
        this.rut_cliente = rut_cliente;
    }

    public String getNombres_cliente() {
        return nombres_cliente;
    }

    public void setNombres_cliente(String nombres_cliente) {
        this.nombres_cliente = nombres_cliente;
    }

    public String getApellidos_cliente() {
        return apellidos_cliente;
    }

    public void setApellidos_cliente(String apellidos_cliente) {
        this.apellidos_cliente = apellidos_cliente;
    }

    public Integer getTelefono_cliente() {
        return telefono_cliente;
    }

    public void setTelefono_cliente(Integer telefono_cliente) {
        this.telefono_cliente = telefono_cliente;
    }

    public String getAfp_cliente() {
        return afp_cliente;
    }

    public void setAfp_cliente(String afp_cliente) {
        this.afp_cliente = afp_cliente;
    }

    public Integer getSistema_salud_cliente() {
        return sistema_salud_cliente;
    }

    public void setSistema_salud_cliente(Integer sistema_salud_cliente) {
        this.sistema_salud_cliente = sistema_salud_cliente;
    }

    public String getDireccion_cliente() {
        return direccion_cliente;
    }

    public void setDireccion_cliente(String direccion_cliente) {
        this.direccion_cliente = direccion_cliente;
    }

    public String getComuna_cliente() {
        return comuna_cliente;
    }

    public void setComuna_cliente(String comuna_cliente) {
        this.comuna_cliente = comuna_cliente;
    }

    public Integer getEdad_cliente() {
        return edad_cliente;
    }

    public void setEdad_cliente(Integer edad_cliente) {
        this.edad_cliente = edad_cliente;
    }

    public void obtenerNombre(){
        System.out.println(nombres_cliente + " " + apellidos_cliente);
    }


    /**
     @param //Este método realiza una validación del dato Sistema de Salud
     */
    public void obtenerSistemaSalud(){
        if (sistema_salud_cliente == 1) {
            System.out.println("Fonasa");
        }else{
            if (sistema_salud_cliente == 2) {
                System.out.println("Isapre");
            }
        }
    }

    @Override
    public void analizarUsuario() {
        //super.analizarUsuario();
        this.toString();
        System.out.println(this.toString());
        System.out.println(direccion_cliente + ", " + comuna_cliente);
    }
}