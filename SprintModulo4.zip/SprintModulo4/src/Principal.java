import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author Sebastián Parra
 * @author Yusnari Alzuru
 * @author Vannya Riffo
 * @author Angelica Romero
 * @version 1.0
 */

public class Principal {
    public static void main(String args[]){

        Contenedor contenedor = new Contenedor();

        ClienteOperaciones clienteOperaciones = new ClienteOperaciones();
        ProfesionalOperaciones profesionalOperaciones = new ProfesionalOperaciones();
        AdministrativoOperaciones administrativoOperaciones = new AdministrativoOperaciones();
        CapacitacionOperaciones capacitacionOperaciones = new CapacitacionOperaciones();

        //Usuario usuario1 = new Usuario("Sebastián Parra","08/01/1992","18116285");

        Scanner sn = new Scanner(System.in);
        boolean salir = false;
        int opcion;

        while (!salir) {
            System.out.println("MENÚ");
            System.out.println("1. Almacenar cliente");
            System.out.println("2. Almacenar profesional");
            System.out.println("3. Almacenar administrativo");
            System.out.println("4. Almacenar capacitación");
            System.out.println("5. Eliminar usuario");
            System.out.println("6. Listar usuarios");
            System.out.println("7. Listar usuario por tipo");
            System.out.println("8. Listar capacitaciones");
            System.out.println("9. Salir");

            try {
                System.out.println("Escribe una de las opciones: ");
                opcion = sn.nextInt();

                switch (opcion) {
                    case 1:
                        System.out.println("Has seleccionado la opcion 1");
                        contenedor.almacenarCliente(clienteOperaciones.leerCliente());
                        break;
                    case 2:
                        System.out.println("Has seleccionado la opcion 2");
                        contenedor.almacenarProfesional(profesionalOperaciones.leerProfesional());
                        break;
                    case 3:
                        System.out.println("Has seleccionado la opcion 3");
                        contenedor.almacenarAdministrativo(administrativoOperaciones.leerAdministrativo());
                        break;
                    case 4:
                        System.out.println("Has seleccionado la opcion 4");
                        contenedor.almacenarCapacitacion(capacitacionOperaciones.leerCapacitacion());
                        break;
                    case 5:
                        System.out.println("Has seleccionado la opcion 5");
                        break;
                    case 6:
                        System.out.println("Has seleccionado la opcion 6");
                        contenedor.listarUsuarios();
                        break;
                    case 7:
                        System.out.println("Has seleccionado la opcion 7");
                        break;
                    case 8:
                        System.out.println("Has seleccionado la opcion 8");
                        contenedor.listarCapacitaciones();
                        break;
                    case 9:
                        salir = true;
                        break;
                    default:
                        System.out.println("Solo números entre 1 y 9");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número del 1 al 9");
                sn.next();
            }
        }
    }
}
