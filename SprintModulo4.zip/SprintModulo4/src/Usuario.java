import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Usuario implements Asesoria {
    private String nombre_usuario;
    private String fecha_nacimiento_usuario;
    private Integer run_usuario;

    @Override
    public String toString() {
        return "Usuario{" +
                "nombre_usuario='" + nombre_usuario + '\'' +
                ", fecha_nacimiento_usuario='" + fecha_nacimiento_usuario + '\'' +
                ", run_usuario='" + run_usuario + '\'' +
                '}';
    }

    public Usuario() {
    }

    public Usuario(String nombre_usuario, String fecha_nacimiento_usuario, Integer run_usuario) {
        this.nombre_usuario = nombre_usuario;
        this.fecha_nacimiento_usuario = fecha_nacimiento_usuario;
        this.run_usuario = run_usuario;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getFecha_nacimiento_usuario() {
        return fecha_nacimiento_usuario;
    }

    public void setFecha_nacimiento_usuario(String fecha_nacimiento_usuario) {
        this.fecha_nacimiento_usuario = fecha_nacimiento_usuario;
    }

    public Integer getRun_usuario() {
        return run_usuario;
    }

    public void setRun_usuario(Integer run_usuario) {
        this.run_usuario = run_usuario;
    }

    //Método para calcular la edad del Usuario a partir de una fecha ingresada
    public void mostrarEdad(){
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate fechaNac = LocalDate.parse(fecha_nacimiento_usuario, fmt);
        LocalDate ahora = LocalDate.now();

        Period periodo = Period.between(fechaNac, ahora);
        System.out.printf("El usuario tiene %s años", periodo.getYears());
    }

    @Override
    public void analizarUsuario() {
        this.toString();
        System.out.println(this);
        System.out.println(nombre_usuario + " - " + run_usuario);
    }
}
