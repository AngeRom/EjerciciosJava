public class Administrativo extends Usuario{
    private String area_administrativo;
    private String experiencia_previa_administrativo;

    @Override
    public String toString() {
        return "Administrativo{" +
                "area_administrativo='" + area_administrativo + '\'' +
                ", experiencia_previa_administrativo='" + experiencia_previa_administrativo + '\'' +
                '}';
    }

    public Administrativo() {
    }

    public Administrativo(String area_administrativo, String experiencia_previa_administrativo) {
        this.area_administrativo = area_administrativo;
        this.experiencia_previa_administrativo = experiencia_previa_administrativo;
    }

    public String getArea_administrativo() {
        return area_administrativo;
    }

    public void setArea_administrativo(String area_administrativo) {
        this.area_administrativo = area_administrativo;
    }

    public String getExperiencia_previa_administrativo() {
        return experiencia_previa_administrativo;
    }

    public void setExperiencia_previa_administrativo(String experiencia_previa_administrativo) {
        this.experiencia_previa_administrativo = experiencia_previa_administrativo;
    }

    public void analizarUsuario(){
        //super.analizarUsuario();
        this.toString();
        System.out.println(this.toString());
        System.out.println(area_administrativo + " - " + experiencia_previa_administrativo);
    }
}
