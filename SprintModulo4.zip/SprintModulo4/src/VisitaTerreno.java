public class VisitaTerreno {
    private Integer id_visita_terreno;
    private Integer rut_cliente;
    private String fecha_accidente;
    private String hora_visita_terreno;
    private String lugar_visita_terreno;
    private String comentarios_visita_terreno;

    @Override
    public String toString() {
        return "VisitaTerreno{" +
                "id_visita_terreno=" + id_visita_terreno +
                ", rut_cliente='" + rut_cliente + '\'' +
                ", fecha_accidente='" + fecha_accidente + '\'' +
                ", hora_visita_terreno='" + hora_visita_terreno + '\'' +
                ", lugar_visita_terreno='" + lugar_visita_terreno + '\'' +
                ", comentarios_visita_terreno='" + comentarios_visita_terreno + '\'' +
                '}';
    }

    public VisitaTerreno() {
    }

    public VisitaTerreno(Integer id_visita_terreno, Integer rut_cliente, String fecha_accidente, String hora_visita_terreno, String lugar_visita_terreno, String comentarios_visita_terreno) {
        this.id_visita_terreno = id_visita_terreno;
        this.rut_cliente = rut_cliente;
        this.fecha_accidente = fecha_accidente;
        this.hora_visita_terreno = hora_visita_terreno;
        this.lugar_visita_terreno = lugar_visita_terreno;
        this.comentarios_visita_terreno = comentarios_visita_terreno;
    }
}
