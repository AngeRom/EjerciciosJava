public interface Asesoria {
    public void analizarUsuario();
}
